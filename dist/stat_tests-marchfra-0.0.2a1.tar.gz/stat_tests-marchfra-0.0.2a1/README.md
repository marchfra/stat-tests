# Statistical test package

The aim of this package is to provide a set of functions to perform statistical tests.\
At the moment only the Z test has been implemented, but more are on the way.